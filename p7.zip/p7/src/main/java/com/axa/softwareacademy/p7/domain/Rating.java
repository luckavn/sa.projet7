package com.axa.softwareacademy.p7.domain;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "rating")
public class Rating {
    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(columnDefinition = "TINYINT")
    private Integer id;
    @Column(length = 125)
    private String moodysRating;
    @Column(length = 125)
    private String sandPRating;
    @Column(length = 125)
    private String fitchRating;
    @Column(columnDefinition = "TINYINT")
    private Integer orderNumber;

    public Rating() {
    }

    public Rating(int id, String moodysRating, String sandPRating, String fitchRating, Integer orderNumber) {
        this.id = id;
        this.moodysRating = moodysRating;
        this.sandPRating = sandPRating;
        this.fitchRating = fitchRating;
        this.orderNumber = orderNumber;
    }

    public Rating(String moodysRating, String sandPRating, String fitchRating, Integer orderNumber) {
        this(0, moodysRating, sandPRating, fitchRating, orderNumber);
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getMoodysRating() { return moodysRating; }
    public void setMoodysRating(String moodysRating) { this.moodysRating = moodysRating; }

    public String getSandPRating() { return sandPRating; }
    public void setSandPRating(String sandPRating) { this.sandPRating = sandPRating; }

    public String getFitchRating() { return fitchRating; }
    public void setFitchRating(String fitchRating) { this.fitchRating = fitchRating; }

    public Integer getOrderNumber() { return orderNumber; }
    public void setOrderNumber(Integer orderNumber) { this.orderNumber = orderNumber; }

    @Override
    public String toString() {
        return "Rating{" + "id=" + id + ", moodysRating='" + moodysRating + '\'' + ", sandPRating='" + sandPRating + '\'' + ", fitchRating='" + fitchRating + '\'' + ", orderNumber=" + orderNumber + '}';
    }
}
